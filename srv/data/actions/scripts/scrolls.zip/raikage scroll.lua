function onUse(cid, item, frompos, item2, topos)
local voc = 200
if isInArray(item_list, getPlayerSlotItem(cid, 4)) then end
	if getPlayerVocation(cid) == voc then
		doPlayerSendTextMessage(cid, MESSAGE_INFO_DESCR, "you are already Raikage!")
		else
		doCreatureSay(cid, "Raikage Owns!!", 19) 
		setPlayerStorageValue(cid, 543245, getPlayerLevel(cid))
	if (doPlayerAddExp(cid, getExperienceForLevel(1)-(getPlayerExperience(cid)))) == LUA_ERROR then end
		doCreatureAddMana(cid, getCreatureMaxMana(cid)-getCreatureMana(cid))
		doCreatureAddHealth(cid, getCreatureMaxHealth(cid)-getCreatureHealth(cid))
	if (doPlayerAddExp(cid, getExperienceForLevel(getPlayerStorageValue(cid, 543245))-(getPlayerExperience(cid)))) == LUA_ERROR then end
		doCreatureAddMana(cid, getCreatureMaxMana(cid)-getCreatureMana(cid))
		doCreatureAddHealth(cid, getCreatureMaxHealth(cid)-getCreatureHealth(cid))
		doSendMagicEffect(getCreaturePosition(cid), 321)
		doCreatureChangeOutfit(cid, {lookType = 326})
		doPlayerSetVocation(cid, voc)
		doRemoveItem(item.uid)
		end
	return true
end

